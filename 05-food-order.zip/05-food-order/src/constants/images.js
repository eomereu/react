import headerMeals from '../assets/meals.jpg';

export default {
  headerMeals
};