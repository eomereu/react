import images from './images';
import DUMMY_MEALS from './dummy_meals';

export { images, DUMMY_MEALS };
